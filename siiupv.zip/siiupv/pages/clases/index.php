<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Aprendiendo Ajax</title>
</head>
<body>
    <form id="form1" action="#">
        <div>
            <label for="nomEstado">Estado:</label>
            <select type="text" name="nomEstado" id="nomEstado" 
            placeholder="Nombre Estado">
                <option value="tamaulipas">Tamaulipas</option>   
                <option value="san luis">San Luis</option>   
                <option value="nuevo leon">Nuevo Leon</option>   
            </select>
        </div>
        <div>
            <select type="text" name="municipios" id="municipios" placeholder="Municipios">
                
            </select>
        </div>
        <div>
            <input type="submit" name="" value="Aceptar">
        </div>
    </form>
    <script type="text/javascript" src="script.js"></script>  
</body>
</html>
