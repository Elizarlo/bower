<!DOCTYPE html>
<html lang="" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form action="#" id ="form1">
      <div class="">
        <label for="nomEstado">Estado:</label>
        <input type="text" name="nomEstado" value="" placeholder="Estado" id='nomEstado'>
      </div>
      <div class="">
        <div id="municipios">        </div>
        <div class="">
          <input type="submit" name="submit" value="Aceptar">
        </div>
      </div>
    </form>
    <script type="text/javascript" src="script.js">   </script>
  </body>
</html>
