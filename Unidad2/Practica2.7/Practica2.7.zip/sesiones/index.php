

<?php
	require 'sesion/abre_sesion.php';
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
 	<title>Inicio</title>
 	<meta charset="utf-8">
 </head>
 <body>
 	<div class="contenedor">
		<?php require 'menu.php'; ?>
	 	<p>
	 		<h1>Bienvenido al sistema integral de Eluis</h1>
	 	</p>
	 	<section>
	 		<p>
				<img src="img/user.png" alt="" width="100" height="100" style="float: left;">
	 			Sistema integral de Eluis, en este sistema podrás encontrar el sistema
				con el cual podras ver las calificaciones de tus semestres podras verlo
				en la parte superior de la página y consultar tus calificaciones.
				<img src="img/logoupv.png" alt="" width="100" height="100" style="float: right;">
	 		</p>
	 	</section>

 	</div>

 </body>
 </html>
