	<header class="clearfix">
		<nav>
			<ul>
				<li><a href="index.php">Inicio</a></li>
				<li><a href="pagina1.php">Información</a></li>
				<li><a href="pagina2.php">Calificación</a></li>
			</ul>
		</nav>

		<div class="derecha">
			<a href="sesion/cerrar_sesion.php">Cerrar Sesión</a>
		</div>
	</header>
